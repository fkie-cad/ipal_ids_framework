.. _factorgraph:

Factor Graphs
=============

API Reference
-------------

.. automodule:: pomegranate.FactorGraph
	:members:
